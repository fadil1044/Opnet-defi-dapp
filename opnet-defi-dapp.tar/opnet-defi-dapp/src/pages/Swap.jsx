import React, { useState } from 'react';
import { ArrowUpDown, Settings, Info, Loader, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import ConnectGuard from '../components/ConnectGuard';

// Real OP_NET contract addresses (mainnet)
const CONTRACTS = {
  MOTOSWAP_ROUTER: 'bcrt1q...', // Replace with deployed Motoswap router address
};

const TOKENS = [
  { symbol: 'BTC', name: 'Bitcoin', decimals: 8, isNative: true, logo: '₿' },
  { symbol: 'MOTO', name: 'Motoswap Token', decimals: 8, isNative: false, logo: '🏍', contractAddress: 'bcrt1p...' },
  { symbol: 'ORDI', name: 'Ordinals Token', decimals: 8, isNative: false, logo: '📜', contractAddress: 'bcrt1p...' },
  { symbol: 'WBTC', name: 'Wrapped BTC', decimals: 8, isNative: false, logo: '🔶', contractAddress: 'bcrt1p...' },
];

function TokenSelect({ token, onSelect, tokens }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 bg-op-darker border border-op-border hover:border-bitcoin/40 rounded-xl px-3 py-2 text-sm font-medium text-white transition-colors"
      >
        <span>{token.logo}</span>
        <span>{token.symbol}</span>
        <span className="text-op-text text-xs">▼</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute top-full left-0 mt-2 w-52 bg-op-card border border-op-border rounded-xl z-20 overflow-hidden shadow-2xl">
            {tokens.map((t) => (
              <button
                key={t.symbol}
                onClick={() => { onSelect(t); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 text-sm hover:bg-op-border transition-colors ${
                  t.symbol === token.symbol ? 'bg-bitcoin/10 text-bitcoin' : 'text-white'
                }`}
              >
                <span>{t.logo}</span>
                <div className="text-left">
                  <div className="font-medium">{t.symbol}</div>
                  <div className="text-op-text text-xs">{t.name}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function SwapContent() {
  const { executeContract, signMessage, address } = useWallet();
  const [tokenIn, setTokenIn] = useState(TOKENS[0]);
  const [tokenOut, setTokenOut] = useState(TOKENS[1]);
  const [amountIn, setAmountIn] = useState('');
  const [slippage, setSlippage] = useState('0.5');
  const [txState, setTxState] = useState('idle'); // idle | signing | pending | success | error
  const [txHash, setTxHash] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Estimated output (in real app, query the router contract)
  const estimatedOut = amountIn ? (parseFloat(amountIn) * 0.998).toFixed(8) : '';

  const handleSwap = async () => {
    if (!amountIn || parseFloat(amountIn) <= 0) return;
    setTxState('signing');
    setErrorMsg('');

    try {
      // Real OP_NET swap transaction
      // This will trigger OP_WALLET popup for user to sign
      const result = await executeContract(
        CONTRACTS.MOTOSWAP_ROUTER,
        'swapExactTokensForTokens',
        [
          Math.floor(parseFloat(amountIn) * 1e8), // amountIn in satoshis
          Math.floor(parseFloat(estimatedOut) * (1 - parseFloat(slippage) / 100) * 1e8), // minAmountOut
          [tokenIn.contractAddress || 'native', tokenOut.contractAddress || 'native'],
          address,
          Math.floor(Date.now() / 1000) + 1200, // deadline: now + 20min
        ],
        tokenIn.isNative ? Math.floor(parseFloat(amountIn) * 1e8) : 0
      );

      setTxHash(result?.txid || result?.hash || 'pending');
      setTxState('success');
    } catch (err) {
      setErrorMsg(err.message || 'Transaction failed');
      setTxState('error');
    }
  };

  const flipTokens = () => {
    setTokenIn(tokenOut);
    setTokenOut(tokenIn);
    setAmountIn(estimatedOut);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10 animate-fade-in">
      <div className="mb-8">
        <h1 className="font-display font-bold text-white text-3xl">Token Swap</h1>
        <p className="text-op-text mt-2">Swap OP-20 tokens on Bitcoin L1 via OP_NET</p>
      </div>

      <div className="bg-op-card border border-op-border rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-op-border">
          <h2 className="font-display font-semibold text-white">Swap</h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-op-text">Slippage: {slippage}%</span>
            <button className="text-op-text hover:text-white p-1 rounded-lg hover:bg-op-border transition-colors">
              <Settings size={15} />
            </button>
          </div>
        </div>

        <div className="p-5 space-y-2">
          {/* From */}
          <div className="bg-op-darker rounded-xl p-4 border border-op-border hover:border-op-text/30 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-op-text">You pay</span>
              <span className="text-xs text-op-text">Balance: —</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="number"
                value={amountIn}
                onChange={(e) => setAmountIn(e.target.value)}
                placeholder="0.0"
                className="flex-1 bg-transparent text-2xl font-display font-semibold text-white outline-none placeholder-op-border min-w-0"
              />
              <TokenSelect token={tokenIn} onSelect={setTokenIn} tokens={TOKENS} />
            </div>
          </div>

          {/* Flip button */}
          <div className="flex items-center justify-center py-1">
            <button
              onClick={flipTokens}
              className="w-9 h-9 rounded-xl bg-op-darker border border-op-border hover:border-bitcoin/40 flex items-center justify-center text-op-text hover:text-bitcoin transition-all hover:rotate-180 duration-300"
            >
              <ArrowUpDown size={15} />
            </button>
          </div>

          {/* To */}
          <div className="bg-op-darker rounded-xl p-4 border border-op-border hover:border-op-text/30 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-op-text">You receive</span>
              <span className="text-xs text-op-text">Balance: —</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={estimatedOut}
                readOnly
                placeholder="0.0"
                className="flex-1 bg-transparent text-2xl font-display font-semibold text-white outline-none placeholder-op-border min-w-0 cursor-default"
              />
              <TokenSelect token={tokenOut} onSelect={setTokenOut} tokens={TOKENS} />
            </div>
          </div>

          {/* Details */}
          {amountIn && estimatedOut && (
            <div className="bg-op-darker rounded-xl p-3 space-y-1.5 border border-op-border">
              <div className="flex justify-between text-xs">
                <span className="text-op-text">Rate</span>
                <span className="text-white font-mono">1 {tokenIn.symbol} ≈ 0.998 {tokenOut.symbol}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-op-text">Price impact</span>
                <span className="text-green-400">{'< 0.01%'}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-op-text">Min received</span>
                <span className="text-white font-mono">
                  {(parseFloat(estimatedOut) * (1 - parseFloat(slippage) / 100)).toFixed(8)} {tokenOut.symbol}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-op-text">Network fee</span>
                <span className="text-white font-mono">~0.00001 BTC</span>
              </div>
            </div>
          )}

          {/* Status */}
          {txState === 'success' && (
            <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 flex items-start gap-3">
              <CheckCircle size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-green-300 text-sm font-medium">Swap submitted!</p>
                {txHash && (
                  <a
                    href={`https://opscan.org/tx/${txHash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-green-400/70 hover:text-green-400 flex items-center gap-1 mt-1"
                  >
                    View on OPScan <ExternalLink size={10} />
                  </a>
                )}
              </div>
            </div>
          )}

          {txState === 'error' && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-start gap-3">
              <AlertCircle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-300 text-sm">{errorMsg}</p>
            </div>
          )}

          {/* Swap Button */}
          <button
            onClick={handleSwap}
            disabled={!amountIn || txState === 'signing' || txState === 'pending'}
            className="w-full bg-bitcoin hover:bg-bitcoin/90 disabled:opacity-40 disabled:cursor-not-allowed text-white font-display font-bold py-4 rounded-xl text-lg transition-all hover:shadow-lg hover:shadow-bitcoin/20 active:scale-[0.98] flex items-center justify-center gap-2"
          >
            {txState === 'signing' ? (
              <>
                <Loader size={18} className="animate-spin" />
                Waiting for OP_WALLET...
              </>
            ) : txState === 'pending' ? (
              <>
                <Loader size={18} className="animate-spin" />
                Broadcasting...
              </>
            ) : (
              'Swap'
            )}
          </button>

          <div className="flex items-center gap-2 justify-center">
            <Info size={12} className="text-op-text" />
            <p className="text-xs text-op-text">OP_WALLET will ask for your approval before signing</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Swap() {
  return (
    <ConnectGuard title="Connect Wallet to Swap">
      <SwapContent />
    </ConnectGuard>
  );
}
