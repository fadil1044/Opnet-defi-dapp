import React, { useState } from 'react';
import { X, ExternalLink, Zap, Shield, AlertCircle, CheckCircle, Loader } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';

const OP_WALLET_INSTALL_URL =
  'https://chromewebstore.google.com/detail/opwallet/pmbjpcmaaladnfpacpmhmnfmpklgbdjb?hl=en';

export default function ConnectWalletModal({ onClose }) {
  const { connect, isConnecting, error, walletInstalled } = useWallet();
  const [step, setStep] = useState('idle'); // idle | connecting | success | error

  const handleConnect = async () => {
    setStep('connecting');
    const success = await connect();
    if (success) {
      setStep('success');
      setTimeout(onClose, 1200);
    } else {
      setStep('error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md animate-slide-up">
        <div className="bg-op-card border border-op-border rounded-2xl overflow-hidden shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-op-border">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-bitcoin/20 flex items-center justify-center">
                <span className="text-bitcoin font-bold text-sm">₿</span>
              </div>
              <h2 className="font-display font-semibold text-white text-lg">Connect Wallet</h2>
            </div>
            <button
              onClick={onClose}
              className="text-op-text hover:text-white transition-colors p-1 rounded-lg hover:bg-op-border"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 space-y-4">
            {/* OP_WALLET Card */}
            <div
              className={`relative border rounded-xl p-5 transition-all duration-200 ${
                walletInstalled
                  ? 'border-bitcoin/40 bg-bitcoin/5 hover:border-bitcoin/70 cursor-pointer'
                  : 'border-op-border bg-op-darker opacity-60'
              }`}
              onClick={walletInstalled && step === 'idle' ? handleConnect : undefined}
            >
              <div className="flex items-center gap-4">
                {/* Icon */}
                <div className="w-12 h-12 rounded-xl bg-bitcoin/20 border border-bitcoin/30 flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">🟠</span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-display font-semibold text-white">OP_WALLET</span>
                    {walletInstalled && (
                      <span className="text-xs bg-green-500/20 text-green-400 border border-green-500/30 px-2 py-0.5 rounded-full">
                        Installed
                      </span>
                    )}
                  </div>
                  <p className="text-op-text text-sm mt-0.5">Bitcoin L1 • Powered by OP_NET</p>
                </div>

                {/* Status indicator */}
                <div className="flex-shrink-0">
                  {step === 'idle' && walletInstalled && (
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  )}
                  {step === 'connecting' && (
                    <Loader size={18} className="text-bitcoin animate-spin" />
                  )}
                  {step === 'success' && (
                    <CheckCircle size={18} className="text-green-400" />
                  )}
                  {step === 'error' && (
                    <AlertCircle size={18} className="text-red-400" />
                  )}
                </div>
              </div>

              {/* Connecting state */}
              {step === 'connecting' && (
                <div className="mt-4 pt-4 border-t border-bitcoin/20">
                  <p className="text-sm text-bitcoin text-center animate-pulse">
                    Waiting for OP_WALLET approval...
                  </p>
                  <p className="text-xs text-op-text text-center mt-1">
                    Check the OP_WALLET popup and approve the connection
                  </p>
                </div>
              )}

              {/* Success state */}
              {step === 'success' && (
                <div className="mt-4 pt-4 border-t border-green-500/20">
                  <p className="text-sm text-green-400 text-center">
                    ✓ Wallet connected successfully!
                  </p>
                </div>
              )}
            </div>

            {/* Not installed */}
            {!walletInstalled && (
              <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle size={16} className="text-orange-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm text-orange-300 font-medium">OP_WALLET not detected</p>
                    <p className="text-xs text-orange-400/70 mt-1">
                      Install OP_WALLET Chrome extension to connect to Bitcoin L1.
                    </p>
                    <a
                      href={OP_WALLET_INSTALL_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 mt-3 text-xs font-medium text-bitcoin hover:text-bitcoin/80 transition-colors"
                    >
                      <ExternalLink size={12} />
                      Install OP_WALLET from Chrome Web Store
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Error */}
            {error && step === 'error' && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm text-red-300">{error}</p>
                    <button
                      onClick={() => setStep('idle')}
                      className="text-xs text-red-400 hover:text-red-300 mt-2 underline"
                    >
                      Try again
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Info pills */}
            <div className="grid grid-cols-2 gap-3 mt-2">
              <div className="flex items-center gap-2 bg-op-darker rounded-lg p-3">
                <Shield size={14} className="text-bitcoin" />
                <span className="text-xs text-op-text">Non-custodial</span>
              </div>
              <div className="flex items-center gap-2 bg-op-darker rounded-lg p-3">
                <Zap size={14} className="text-bitcoin" />
                <span className="text-xs text-op-text">Bitcoin L1</span>
              </div>
            </div>

            {/* Connect button for installed wallet */}
            {walletInstalled && step === 'idle' && (
              <button
                onClick={handleConnect}
                className="w-full bg-bitcoin hover:bg-bitcoin/90 text-white font-display font-semibold py-3.5 rounded-xl transition-all duration-200 hover:shadow-lg hover:shadow-bitcoin/20 active:scale-[0.98]"
              >
                Connect OP_WALLET
              </button>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 pb-6">
            <p className="text-xs text-op-text text-center">
              By connecting, you agree to interact with Bitcoin L1 smart contracts.{' '}
              <a
                href="https://docs.opnet.org"
                target="_blank"
                rel="noopener noreferrer"
                className="text-bitcoin/70 hover:text-bitcoin"
              >
                Learn more
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
